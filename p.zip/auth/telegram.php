<?php
$id_telegram = "6728611462";
$id_botTele  = "7967257967:AAEhvuBgxiKS9yr6jbYOsFppy7aRqauW8jE";
?>
